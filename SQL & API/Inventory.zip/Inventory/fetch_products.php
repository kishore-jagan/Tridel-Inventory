<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Database configuration
$dbHost = 'localhost';
$dbName = 'api';
$dbUser = 'root';
$dbPassword = '';

// Create a database connection
$conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the request method is GET
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Retrieve data from electrical table
    $electricalSql = "SELECT * FROM electrical";
    $electricalResult = $conn->query($electricalSql);
    $electricalData = [];

    if ($electricalResult->num_rows > 0) {
        while ($row = $electricalResult->fetch_assoc()) {
            $electricalData[] = $row;
        }
    }

    // Retrieve data from mechanical table
    $mechanicalSql = "SELECT * FROM mechanical";
    $mechanicalResult = $conn->query($mechanicalSql);
    $mechanicalData = [];

    if ($mechanicalResult->num_rows > 0) {
        while ($row = $mechanicalResult->fetch_assoc()) {
            $mechanicalData[] = $row;
        }
    }

    // Retrieve data from IT table
    $itSql = "SELECT * FROM it";
    $itResult = $conn->query($itSql);
    $itData = [];

    if ($itResult->num_rows > 0) {
        while ($row = $itResult->fetch_assoc()) {
            $itData[] = $row;
        }
    }

    // Combine data from both tables
    // $combinedData = ['electrical' => $electricalData, 'mechanical' => $mechanicalData];
    $combinedData = (['status' => 'Success', 'products' => array_merge($electricalData, $mechanicalData, $itData)]);

    // Return combined data as JSON response
    http_response_code(200);
    echo json_encode($combinedData);
} else {
    // Handle invalid request method
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
}

// Close the database connection
$conn->close();
?>