<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Include Barcode library
require 'vendor/autoload.php';

use Picqer\Barcode\BarcodeGeneratorHTML;

// Your database credentials
$dbHost = 'localhost';
$dbName = 'api';
$dbUser = 'root';
$dbPassword = '';

// Create connection
$conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data from the request
    $name = isset($_POST['name']) ? $_POST['name'] : null;
    $serial_no = isset($_POST['serial_no']) ? $_POST['serial_no'] : null;
    $model_no = isset($_POST['model_no']) ? $_POST['model_no'] : null;
    $category = isset($_POST['category']) ? $_POST['category'] : null;
    $location = isset($_POST['location']) ? $_POST['location'] : null;
    $type = isset($_POST['type']) ? $_POST['type'] : null;
    $status = isset($_POST['status']) ? $_POST['status'] : null;
    $qty = isset($_POST['qty']) ? $_POST['qty'] : null;
    $vendor_name = isset($_POST['vendor_name']) ? $_POST['vendor_name'] : null;
    $date = isset($_POST['date']) ? $_POST['date'] : null;
    $Stock_in_out = isset($_POST['Stock_in_out']) ? $_POST['Stock_in_out'] : null;
    $Desc = isset($_POST['Desc']) ? $_POST['Desc'] : null;
    $price = isset($_POST['price']) ? $_POST['price'] : null;
    $total_price = isset($_POST['total_price']) ? $_POST['total_price'] : null;

    // Check if all required fields are provided
    if ($name && $serial_no && $model_no && $category && $location && $type && $qty && $status && $vendor_name && $date && $Stock_in_out && $Desc && $price && $total_price) {
        // Generate a unique barcode data
        $barcodeData = uniqid();

        // Generate Barcode HTML
        $barcodeGenerator = new BarcodeGeneratorHTML();
        $barcodeHTML = $barcodeGenerator->getBarcode($barcodeData, $barcodeGenerator::TYPE_CODE_128);

        // Check if model number already exists
        $checkSql = "SELECT * FROM $category WHERE model_no = ?";
        $checkStmt = $conn->prepare($checkSql);
        $checkStmt->bind_param("s", $model_no);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();

        if ($checkResult->num_rows > 0) {
            // Model number already exists
            http_response_code(200);
            echo json_encode(['status' => 'Failed', 'remark' => 'Model number already available']);
        } else {

            $selectedVendor = $vendor_name;

            // Model number does not exist, proceed to save data
            $sql = "INSERT INTO $category (name, serial_no, model_no, category, location, type, qty, status, vendor_name, date, Stock_in_out, Decs, barcode, price, total_price) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssssssssssss", $name, $serial_no, $model_no, $category, $location, $type, $qty, $status, $selectedVendor, $date, $Stock_in_out, $Desc, $barcodeData, $price, $total_price);

            if ($stmt->execute()) {
                // Successfully added product with barcode
                http_response_code(200);
                echo json_encode(['status' => 'success', 'remark' => 'Product successfully added with barcode']);
            } else {
                // Failed to add product
                http_response_code(500);
                echo json_encode(['error' => 'Failed to add product']);
            }

            $stmt->close();
        }

        $checkStmt->close();
    } else {
        // Missing required fields
        http_response_code(400);
        echo json_encode(['error' => 'Missing required fields']);
    }
} else {
    // Handle invalid request method
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
}

// Close the database connection
$conn->close();
?>