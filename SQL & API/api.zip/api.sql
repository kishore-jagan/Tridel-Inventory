-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 31, 2024 at 11:31 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `api`
--

-- --------------------------------------------------------

--
-- Table structure for table `dispatch`
--

CREATE TABLE `dispatch` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `category` enum('electrical','mechanical','it') NOT NULL,
  `vendor_name` varchar(255) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `dispatch_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dispatch`
--

INSERT INTO `dispatch` (`id`, `item_id`, `category`, `vendor_name`, `quantity`, `dispatch_date`) VALUES
(1, 1, 'electrical', 'Mani', NULL, '2024-07-09 06:32:31'),
(2, 2, 'electrical', 'Mani', NULL, '2024-07-09 06:32:31'),
(3, 3, 'electrical', 'Mani', NULL, '2024-07-09 06:32:31'),
(4, 2, 'mechanical', 'IG solutions', NULL, '2024-07-09 06:46:26');

-- --------------------------------------------------------

--
-- Table structure for table `dispatches`
--

CREATE TABLE `dispatches` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `products` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`products`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dispatches`
--

INSERT INTO `dispatches` (`id`, `customer_name`, `products`, `created_at`) VALUES
(28, 'Mercy electronics', '[{\"product_name\":\"Rope\",\"serial_no\":\"LFU466\",\"model_no\":\"X12345\",\"category\":\"IT\",\"quantity\":4,\"price\":1000,\"total_price\":\"4000.0\"}]', '2024-07-29 09:14:00'),
(29, 'Gori', '[{\"product_name\":\"Rope\",\"serial_no\":\"LFU466\",\"model_no\":\"X12345\",\"category\":\"IT\",\"quantity\":2,\"price\":1000,\"total_price\":\"2000.0\"}]', '2024-07-29 09:14:51'),
(30, 'kishore', '[{\"product_name\":\"Box\",\"serial_no\":\"J325454351\",\"model_no\":\"L231545\",\"category\":\"Mechanical\",\"quantity\":2,\"price\":2000,\"total_price\":\"4000.0\"}]', '2024-07-29 09:16:06'),
(31, 'kishore', '[{\"product_name\":\"Rope\",\"serial_no\":\"LFU466\",\"model_no\":\"X12345\",\"category\":\"IT\",\"quantity\":1,\"price\":1000,\"total_price\":\"1000.0\"},{\"product_name\":\"poleeee\",\"serial_no\":\"QtYb123\",\"model_no\":\"D12345\",\"category\":\"Mechanical\",\"quantity\":2,\"price\":500,\"total_price\":\"1000.0\"},{\"product_name\":\"phones\",\"serial_no\":\"QtYb123\",\"model_no\":\"C12345\",\"category\":\"Electrical\",\"quantity\":1,\"price\":10000,\"total_price\":\"10000.0\"}]', '2024-07-30 03:56:47');

-- --------------------------------------------------------

--
-- Table structure for table `electrical`
--

CREATE TABLE `electrical` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `model_no` varchar(200) NOT NULL,
  `serial_no` varchar(200) NOT NULL,
  `category` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `qty` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `vendor_name` varchar(200) NOT NULL,
  `Stock_in_out` varchar(200) NOT NULL,
  `Decs` varchar(200) NOT NULL,
  `date` date DEFAULT NULL,
  `barcode` varchar(250) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `electrical`
--

INSERT INTO `electrical` (`id`, `name`, `model_no`, `serial_no`, `category`, `location`, `type`, `qty`, `status`, `vendor_name`, `Stock_in_out`, `Decs`, `date`, `barcode`, `price`, `total_price`) VALUES
(1, 'Electric wireee', 'A12345', 'QtYb123', 'Electrical', 'Inhouse', 'Rental', '22', 'good', 'Mercy electronics', 'Stock In', 'good quality', '2024-06-25', '667a6a1f7564a', 10.00, 220.00),
(2, 'phones', 'C12345', 'QtYb123', 'Electrical', 'Inhouse', 'Rental', '7', 'good', 'Mercy electronics', 'Stock In', 'good', '2024-06-25', '667add99bdce1', 10000.00, 70000.00),
(3, 'Lan Cable', 'E12345', 'QtYb123', 'Electrical', 'Inhouse', 'Rental', '5', 'working', 'Ag traders', 'Stock In', 'working', '2024-06-27', '667d3bf45aac6', 100.00, 500.00),
(4, 'Stabler', 'F12345', 'QtYb123', 'Electrical', 'Inhouse', 'Rental', '10', 'good', 'Mercy electronics', 'Stock In', 'good', '2024-06-27', '667d40d1513f1', 20.00, 200.00),
(6, 'Charger', 'J12345', 'QtYb123', 'Electrical', 'Inhouse', 'Rental', '4', 'ok', 'mumbai materials', 'Stock In', 'good', '2024-06-28', '667e4f3373c08', 200.00, 800.00),
(8, 'Tap', 'L12345', 'QtYb123', 'Electrical', 'Inhouse', 'Rental', '6', 'ok', 'mumbai materials', 'Stock In', 'ok', '2024-07-05', '6687d91ccd88c', 40.00, 240.00),
(9, 'Note book', 'M12345', 'QtYb123', 'Electrical', 'Inhouse', 'Rental', '2', 'mm', 'mumbai materials', 'Stock In', 'ok', '2024-07-06', '668923d587f28', 200.00, 400.00),
(11, 'Sticks', 'V21321424123', 'D12424343432431', 'Electrical', 'Inhouse', 'Rental', '2', 'ok', 'Virus', 'Stock In', 'ok', '2024-07-24', '66a0d2b568764', 50.00, 100.00);

-- --------------------------------------------------------

--
-- Table structure for table `it`
--

CREATE TABLE `it` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `model_no` varchar(200) NOT NULL,
  `serial_no` varchar(200) NOT NULL,
  `category` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `qty` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `vendor_name` varchar(200) NOT NULL,
  `Stock_in_out` varchar(200) NOT NULL,
  `Decs` varchar(200) NOT NULL,
  `date` date DEFAULT NULL,
  `barcode` varchar(200) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `it`
--

INSERT INTO `it` (`id`, `name`, `model_no`, `serial_no`, `category`, `location`, `type`, `qty`, `status`, `vendor_name`, `Stock_in_out`, `Decs`, `date`, `barcode`, `price`, `total_price`) VALUES
(1, 'Rope', 'X12345', 'LFU466', 'IT', 'Inhouse', 'Rental', '1', '250 meter rope', 'Ritchi street', 'Stock In', 'ok', '2024-07-06', '6689297a6bb36', 1000.00, 1000.00),
(3, 'Vessels', 'G123143353553', 'L122434254354', 'IT', 'Inhouse', 'Assets', '2', 'Good', 'Virus', 'Stock In', 'Good', '2024-07-18', '6698e9b636130', 200.00, 400.00),
(4, 'Wallet', 'F131245454545', 'K12445135', 'IT', 'Inhouse', 'Assets', '5', 'Good', 'Lord', 'Stock In', 'Good', '2024-07-18', '6698eae2558a8', 200.00, 1000.00),
(5, 'Cups', 'G123432413434', 'L124465757', 'IT', 'Warehouse', 'Assets', '30', 'For Clients', 'Ranjith', 'Stock In', 'Good', '2024-07-19', '669a0bb080015', 20.00, 600.00),
(6, 'Pencils', 'V32432541', 'G124154', 'IT', 'Inhouse', 'Assets', '5', 'Good', 'mumbai materials', 'Stock In', 'Good', '2024-07-19', 'Pencils|G124154|V32432541|5|669a1648ecc42', 10.00, 50.00);

-- --------------------------------------------------------

--
-- Table structure for table `mechanical`
--

CREATE TABLE `mechanical` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `model_no` varchar(200) NOT NULL,
  `serial_no` varchar(200) NOT NULL,
  `category` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `qty` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `vendor_name` varchar(200) NOT NULL,
  `Stock_in_out` varchar(200) NOT NULL,
  `Decs` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `barcode` varchar(250) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mechanical`
--

INSERT INTO `mechanical` (`id`, `name`, `model_no`, `serial_no`, `category`, `location`, `type`, `qty`, `status`, `vendor_name`, `Stock_in_out`, `Decs`, `date`, `barcode`, `price`, `total_price`) VALUES
(2, 'Winch', 'B12345', 'QtYb123QtYb123', 'Mechanical', 'Inhouse', 'Assets', '19', 'good', 'Ritchi street', 'Stock In', 'Good', '2024-06-25', '667aa6d570298', 100.00, 1900.00),
(3, 'poleeee', 'D12345', 'QtYb123', 'Mechanical', 'Inhouse', 'Assets', '3', 'ok', 'mumbai materials', 'Stock In', 'ok', '2023-10-12', '667cfb2ca7f0e', 500.00, 1500.00),
(4, 'Laptop', 'F12345', 'QtYb123', 'Mechanical', 'Inhouse', 'Rental', '2', 'ok', 'Kr info tech', 'Stock In', 'good', '2024-06-27', '667d3e3d76e5c', 50000.00, 100000.00),
(5, 'Rj235', 'G12345', 'QtYb123', 'Mechanical', 'Inhouse', 'Rental', '1', 'ok', 'Ritchi street', 'Stock In', 'ok', '2024-06-27', '667d47db8e8ff', 5000.00, 5000.00),
(6, 'Phone', 'U12345', 'QtYb123', 'Mechanical', 'Warehouse', 'Assets', '2', 'good', 'Ritchi street', 'Stock In', 'Good', '2024-06-28', '667e4d60cddc8', 50000.00, 100000.00),
(7, 'Charger', 'J12345', 'QtYb123', 'Mechanical', 'Warehouse', 'Assets', '8', 'ok', 'Ag traders', 'Stock In', 'ok', '2024-07-05', '6687d02f8b094', 100.00, 800.00),
(8, 'Notes', 'K12345', 'QtYb123', 'Mechanical', 'Warehouse', 'Assets', '4', 'ok', 'Ritchi street', 'Stock In', 'ok', '2024-07-05', '6687d5ac53593', 50.00, 200.00),
(9, 'Sandisk', 'H12321435354545', 'G1233243545', 'Mechanical', 'Warehouse', 'Assets', '3', 'Good', 'Virus', 'Stock In', 'Good', '2024-07-18', '6698ea214f9f3', 2000.00, 6000.00),
(10, 'Switches', 'J12343545', 'G12414541', 'Mechanical', 'Inhouse', 'Rental', '3', 'Good', 'mumbai materials', 'Stock In', 'Good', '2024-07-18', '6698eb32b733f', 10.00, 30.00),
(11, 'Box', 'L231545', 'J325454351', 'Mechanical', 'Warehouse', 'Assets', '3', 'good', 'mumbai materials', 'Stock In', 'Good', '2024-07-20', '669b86fb23be1', 2000.00, 6000.00);

-- --------------------------------------------------------

--
-- Table structure for table `persons`
--

CREATE TABLE `persons` (
  `name` varchar(200) NOT NULL,
  `userName` varchar(200) NOT NULL,
  `phone_number` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `role` varchar(200) NOT NULL,
  `id` int(11) NOT NULL,
  `employee_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `persons`
--

INSERT INTO `persons` (`name`, `userName`, `phone_number`, `password`, `email_id`, `role`, `id`, `employee_id`) VALUES
('kishore', 'kishore', '123456789', '98c3b24124499b152e7bdfedd8a38102', 'kishore@gmail.com', 'Admin', 14, '111111'),
('Gana', 'Gana', '123456789', 'd59901b35800e622044ac4125fbe03f7', 'gana@gmail.com', 'Admin', 15, '1002'),
('Kavi', 'kavi', '9600701788', '919d747e7bec6b5c2728be178f4ff06d', 'kavi@gmail.com', 'User', 16, '1003'),
('Garudan', 'garudan', '9876543210', 'f62934fa8cd6b6a19981d0d31a727372', 'garudan@gmail.com', 'User', 26, '1004'),
('Mani', 'mani', '13456765432', '6e61eb1c893167b00a1631e93d888c4f', 'mani@gmail.com', 'User', 27, '1000110');

-- --------------------------------------------------------

--
-- Table structure for table `stockout`
--

CREATE TABLE `stockout` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `serial_no` varchar(200) NOT NULL,
  `model_no` varchar(200) NOT NULL,
  `category` varchar(200) NOT NULL,
  `qty` varchar(200) NOT NULL,
  `price` longtext NOT NULL,
  `total_price` longtext NOT NULL,
  `stock` varchar(200) NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stockout`
--

INSERT INTO `stockout` (`id`, `name`, `serial_no`, `model_no`, `category`, `qty`, `price`, `total_price`, `stock`, `date`) VALUES
(2, 'Winch', 'QtYb123', 'B12345', 'mechanical', '19', '100.00', '1900', 'Stock Out', '2024-07-05'),
(3, 'phones', 'QtYb123', 'C12345', 'electrical', '7', '10000.00', '70000', 'Stock Out', '2024-07-30'),
(4, 'Electric wireee', 'QtYb123', 'A12345', 'electrical', '23', '10.00', '230', 'Stock Out', '2024-07-29'),
(5, 'pole', 'QtYb123', 'D12345', 'mechanical', '7', '500.00', '3500', 'Stock Out', '2024-07-30'),
(6, 'boxee', 'QtYb123', 'H12345', 'electrical', '1', '5000.00', '5000', 'Stock Out', '2024-06-28'),
(7, 'Tap', 'QtYb123', 'L12345', 'electrical', '3', '40.00', '120', 'Stock Out', '2024-07-29'),
(8, 'Charger', 'QtYb123', 'J12345', 'mechanical', '3', '100.00', '300', 'Stock Out', '2024-07-16'),
(9, 'Notes', 'QtYb123', 'K12345', 'mechanical', '2', '50.00', '100', 'Stock Out', '2024-07-15'),
(10, 'Rope', 'LFU466', 'X12345', 'IT', '4', '1000.00', '4000', 'Stock Out', '2024-07-30'),
(11, 'Laptop', 'QtYb123', 'F12345', 'mechanical', '1', '50000.00', '50000', 'Stock Out', '2024-07-18'),
(12, 'Lan Cable', 'QtYb123', 'E12345', 'electrical', '1', '100.00', '100', 'Stock Out', '2024-07-18'),
(13, 'Vessels', 'L122434254354', 'G123143353553', 'IT', '3', '200.00', '600', 'Stock Out', '2024-07-26'),
(14, 'Rj235', 'QtYb123', 'G12345', 'Mechanical', '1', '5000.00', '5000', 'Stock Out', '2024-07-26'),
(15, 'Sticks', 'D12424343432431', 'V21321424123', 'Electrical', '1', '50.00', '50', 'Stock Out', '2024-07-29'),
(16, 'Sandisk', 'G1233243545', 'H12321435354545', 'Mechanical', '1', '2000.00', '2000', 'Stock Out', '2024-07-29'),
(17, 'Switches', 'G12414541', 'J12343545', 'Mechanical', '1', '10.00', '10', 'Stock Out', '2024-07-29'),
(18, 'Box', 'J325454351', 'L231545', 'Mechanical', '2', '2000.00', '4000', 'Stock Out', '2024-07-29');

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE `vendor` (
  `id` int(11) NOT NULL,
  `vendorName` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`id`, `vendorName`) VALUES
(1, 'Mercy electronics'),
(2, 'Ritchi street'),
(3, 'mumbai materials'),
(4, 'Ag traders'),
(5, 'Kr info tech'),
(6, 'IG solutions'),
(7, 'Elan'),
(8, 'Virus'),
(9, 'Lord'),
(10, 'Ranjith'),
(11, 'mani'),
(12, 'venus'),
(13, 'Raayan'),
(14, 'Gori'),
(15, 'kishore');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dispatch`
--
ALTER TABLE `dispatch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dispatches`
--
ALTER TABLE `dispatches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `electrical`
--
ALTER TABLE `electrical`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `it`
--
ALTER TABLE `it`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mechanical`
--
ALTER TABLE `mechanical`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `persons`
--
ALTER TABLE `persons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stockout`
--
ALTER TABLE `stockout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendor`
--
ALTER TABLE `vendor`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dispatch`
--
ALTER TABLE `dispatch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dispatches`
--
ALTER TABLE `dispatches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `electrical`
--
ALTER TABLE `electrical`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `it`
--
ALTER TABLE `it`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `mechanical`
--
ALTER TABLE `mechanical`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `persons`
--
ALTER TABLE `persons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `stockout`
--
ALTER TABLE `stockout`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `vendor`
--
ALTER TABLE `vendor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
